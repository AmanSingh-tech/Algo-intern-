import express from 'express';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import dotenv from 'dotenv';

dotenv.config();

const route = express.Router();
const jwtpasskey = process.env.JWT_PASSKEY || '';
const prisma = new PrismaClient();

// Auth middleware to decode token and attach userId to request
function authenticateToken(req, res, next) {
  const tokenHeader = req.headers.usertoken;
  if (!tokenHeader) {
    return res.status(401).json({ success: false, message: "Authorization token missing" });
  }

  try {
    const token = tokenHeader.split(" ")[1];
    const decoded = jwt.verify(token, jwtpasskey);

    if (typeof decoded !== 'object' || !decoded || !('id' in decoded)) {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    req.userId = decoded.id;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Token verification failed",
      error: error.message || String(error),
    });
  }
}

// GET /profile
route.get('/profile', authenticateToken, async (req, res) => {
  const userId = req.userId;

  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        username: true,
        firstname: true,
        lastname: true,
        DOB: true,
        comments: true,
      },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    const uniqueSolved = await prisma.solve.findMany({
      where: { userId },
      distinct: ['problemId'],
      select: { problemId: true },
    });

    return res.json({
      success: true,
      user: {
        ...user,
        solved: uniqueSolved,
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Failed to fetch profile",
      error: error.message || String(error),
    });
  }
});

// GET /submission
route.get('/submission', authenticateToken, async (req, res) => {
  const userId = req.userId;

  try {
    const response = await prisma.solve.findMany({
      where: { userId },
      orderBy: { date: 'desc' },
      select: {
        code: true,
        date: true,
        problem: {
          select: {
            title: true,
          },
        },
      },
    });

    return res.json({
      success: true,
      solved: response,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Failed to fetch submissions",
      error: error.message || String(error),
    });
  }
});

// GET /submission/:pid
route.get('/submission/:pid', authenticateToken, async (req, res) => {
  const userId = req.userId;
  const pid = req.params.pid;

  if (!pid) {
    return res.status(400).json({
      success: false,
      message: "Problem ID missing",
    });
  }

  try {
    const response = await prisma.solve.findMany({
      where: {
        userId,
        problemId: pid,
      },
      select: {
        code: true,
        date: true,
      },
    });

    return res.json({
      success: true,
      submissions: response,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Failed to fetch submissions",
      error: error.message || String(error),
    });
  }
});

export default route;
