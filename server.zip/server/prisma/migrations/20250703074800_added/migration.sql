-- AlterTable
ALTER TABLE "Solve" ADD COLUMN     "language" TEXT NOT NULL DEFAULT 'cpp';
